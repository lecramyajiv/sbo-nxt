#!/bin/bash

export q1=${q1:-/opt/qtcreator}
export q2=${q2:-$q1/bin}
export q3=${q3:-$q1/lib64}
export q4=${q4:-$q1/libexec/qtcreator}

export PATH=$PATH:$q1:$q2:$q3:$q4
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$q3:$q4


#export q4=${q4:-$q3/elfutils}
#export q5=${q5:-$q3/qbs}
#export q6=${q6:-$q3/qtcreator}
#export q7=${q7:-$q6/plugins}
#export q8=${q8:-$q3/Qt}
#export q9=${q9:-$q8/lib}
#export qa=${qa:-$q8/plugins}
#export qb=${qb:-$qa/assetimporters}
#export qc=${qc:-$qa/designer}
#export qd=${qd:-$qa/iconengines}
#export qe=${qe:-$qa/imageformats}
#export qf=${qf:-$qa/platforminputcontexts}
#export qg=${qg:-$qa/platforms}
#export qh=${qh:-$qa/platformthemes}
#export qi=${qi:-$qa/printsupport}
#export qj=${qj:-$qa/qmltooling}
#export qk=${qk:-$qa/sqldrivers}
#export ql=${ql:-$qa/tls}
#export qm=${qm:-$qa/wayland-decoration-client}
#export qn=${qn:-$qa/wayland-graphics-integration-client}
#export qo=${qo:-$qa/wayland-shell-integration}
#export qp=${qp:-$qa/xcbglintegrations}
#export qr=${qr:-$q8/bin}
#export qs=${qs:-$q8/qml}


#export PATH=$PATH:$q1:$q2:$q3:$q4:$q5:$q6:$q7:$q8:$q9:$qa:$qb:$qc:$qd:$qe:$qf:$qg:$qi:$qj:$qk:$ql:$qm:$qn:$qo:$qp:$qq:$qr:$qs
#export PKG_CONFIG_PATH=$PKG_CONFIG_PATH:$q4
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$q3:$q4:$q5:$q6:$q7:$q8:$q9:$qa:$qb:$qc:$qd:$qe:$qf:$qg:$qi:$qj:$qk:$ql:$qm:$qn:$qo:$qp:$qq:$qr:$qs
