from distutils.core import setup

setup(name='patch', version='1.16', py_modules=['patch'], )
