#include <config.h>
#define EEALLOC_INLINE _GL_EXTERN_INLINE
#include "eealloc.h"
