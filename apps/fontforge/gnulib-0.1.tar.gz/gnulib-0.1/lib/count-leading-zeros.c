#include <config.h>
#define COUNT_LEADING_ZEROS_INLINE _GL_EXTERN_INLINE
#include "count-leading-zeros.h"
