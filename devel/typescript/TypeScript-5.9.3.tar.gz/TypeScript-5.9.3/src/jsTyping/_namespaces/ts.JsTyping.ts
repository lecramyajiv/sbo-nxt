/* Generated file to emulate the ts.JsTyping namespace. */

export * from "../jsTyping.js";
