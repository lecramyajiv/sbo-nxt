/* Generated file to emulate the ts namespace. */

export * from "../../compiler/_namespaces/ts.js";
import * as JsTyping from "./ts.JsTyping.js";
export { JsTyping };
import * as server from "./ts.server.js";
export { server };
