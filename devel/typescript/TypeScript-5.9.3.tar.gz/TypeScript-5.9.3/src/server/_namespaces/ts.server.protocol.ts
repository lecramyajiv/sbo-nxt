/* Generated file to emulate the ts.server.protocol namespace. */

export * from "../protocol.js";
