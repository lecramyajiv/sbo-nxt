/* Generated file to emulate the ts.performance namespace. */

export * from "../performance.js";
