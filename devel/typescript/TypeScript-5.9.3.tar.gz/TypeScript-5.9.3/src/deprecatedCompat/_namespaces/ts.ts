/* Generated file to emulate the ts namespace. */

export * from "../../compiler/_namespaces/ts.js";
export * from "../deprecations.js";
