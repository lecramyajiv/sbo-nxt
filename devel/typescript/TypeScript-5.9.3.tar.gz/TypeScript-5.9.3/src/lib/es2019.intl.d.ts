declare namespace Intl {
    interface DateTimeFormatPartTypesRegistry {
        unknown: never;
    }
}
