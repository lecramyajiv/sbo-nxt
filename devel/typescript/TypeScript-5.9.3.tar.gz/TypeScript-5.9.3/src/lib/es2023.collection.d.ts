interface WeakKeyTypes {
    symbol: symbol;
}
