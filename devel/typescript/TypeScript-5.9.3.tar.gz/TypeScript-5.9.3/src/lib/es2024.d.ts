/// <reference lib="es2023" />
/// <reference lib="es2024.arraybuffer" />
/// <reference lib="es2024.collection" />
/// <reference lib="es2024.object" />
/// <reference lib="es2024.promise" />
/// <reference lib="es2024.regexp" />
/// <reference lib="es2024.sharedmemory" />
/// <reference lib="es2024.string" />
