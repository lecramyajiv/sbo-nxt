/// <reference lib="es2020" />
/// <reference lib="es2021.promise" />
/// <reference lib="es2021.string" />
/// <reference lib="es2021.weakref" />
/// <reference lib="es2021.intl" />
