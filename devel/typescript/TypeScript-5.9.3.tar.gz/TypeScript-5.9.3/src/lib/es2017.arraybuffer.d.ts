interface ArrayBufferConstructor {
    new (): ArrayBuffer;
}
