declare namespace Intl {
    // Empty
}
