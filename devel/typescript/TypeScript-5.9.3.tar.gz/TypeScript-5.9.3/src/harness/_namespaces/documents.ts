/* Generated file to emulate the documents namespace. */

export * from "../documentsUtil.js";
