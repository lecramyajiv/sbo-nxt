/* Generated file to emulate the Harness.SourceMapRecorder namespace. */

export * from "../sourceMapRecorder.js";
