/* Generated file to emulate the collections namespace. */

export * from "../collectionsImpl.js";
