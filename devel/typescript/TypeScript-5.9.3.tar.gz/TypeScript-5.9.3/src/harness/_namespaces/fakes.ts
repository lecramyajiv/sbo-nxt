/* Generated file to emulate the fakes namespace. */

export * from "../fakesHosts.js";
