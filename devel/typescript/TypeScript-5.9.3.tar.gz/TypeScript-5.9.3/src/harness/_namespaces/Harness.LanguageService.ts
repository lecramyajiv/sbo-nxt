/* Generated file to emulate the Harness.LanguageService namespace. */

export * from "../harnessLanguageService.js";
