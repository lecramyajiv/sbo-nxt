/* Generated file to emulate the FourSlash namespace. */

export * from "../fourslashImpl.js";
