/* Generated file to emulate the FourSlashInterface namespace. */

export * from "../fourslashInterfaceImpl.js";
