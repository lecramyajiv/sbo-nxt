/* Generated file to emulate the vfs namespace. */

export * from "../vfsUtil.js";
