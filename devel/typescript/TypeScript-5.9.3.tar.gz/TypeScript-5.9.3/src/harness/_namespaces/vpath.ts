/* Generated file to emulate the vpath namespace. */

export * from "../vpathUtil.js";
