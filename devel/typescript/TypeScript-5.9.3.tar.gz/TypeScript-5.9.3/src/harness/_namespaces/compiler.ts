/* Generated file to emulate the compiler namespace. */

export * from "../compilerImpl.js";
