/* Generated file to emulate the ts namespace. */

export * from "../../compiler/_namespaces/ts.js";
export * from "../../services/_namespaces/ts.js";
export * from "../../jsTyping/_namespaces/ts.js";
export * from "../../server/_namespaces/ts.js";
export * from "../../typingsInstallerCore/_namespaces/ts.js";
export * from "../../deprecatedCompat/_namespaces/ts.js";
export * from "../harnessGlobals.js";
import * as server from "./ts.server.js";
export { server };
