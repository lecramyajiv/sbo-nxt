/* Generated file to emulate the ts.SignatureHelp namespace. */

export * from "../signatureHelp.js";
