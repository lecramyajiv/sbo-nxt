/* Generated file to emulate the ts.InlayHints namespace. */

export * from "../inlayHints.js";
