/* Generated file to emulate the ts.SmartSelectionRange namespace. */

export * from "../smartSelection.js";
