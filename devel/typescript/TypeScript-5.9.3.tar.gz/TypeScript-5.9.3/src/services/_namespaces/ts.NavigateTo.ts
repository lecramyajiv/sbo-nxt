/* Generated file to emulate the ts.NavigateTo namespace. */

export * from "../navigateTo.js";
