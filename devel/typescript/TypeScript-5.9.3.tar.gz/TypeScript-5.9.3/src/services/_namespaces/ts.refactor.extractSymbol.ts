/* Generated file to emulate the ts.refactor.extractSymbol namespace. */

export * from "../refactors/extractSymbol.js";
