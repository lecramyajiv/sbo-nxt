/* Generated file to emulate the ts.refactor.inferFunctionReturnType namespace. */

export * from "../refactors/inferFunctionReturnType.js";
