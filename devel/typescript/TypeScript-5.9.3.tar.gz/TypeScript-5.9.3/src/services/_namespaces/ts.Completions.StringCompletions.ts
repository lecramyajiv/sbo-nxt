/* Generated file to emulate the ts.Completions.StringCompletions namespace. */

export * from "../stringCompletions.js";
