/* Generated file to emulate the ts.textChanges namespace. */

export * from "../textChanges.js";
