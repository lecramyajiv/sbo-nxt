/* Generated file to emulate the ts.OutliningElementsCollector namespace. */

export * from "../outliningElementsCollector.js";
