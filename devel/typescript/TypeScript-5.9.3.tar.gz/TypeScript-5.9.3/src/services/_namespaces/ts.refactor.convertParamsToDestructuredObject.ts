/* Generated file to emulate the ts.refactor.convertParamsToDestructuredObject namespace. */

export * from "../refactors/convertParamsToDestructuredObject.js";
