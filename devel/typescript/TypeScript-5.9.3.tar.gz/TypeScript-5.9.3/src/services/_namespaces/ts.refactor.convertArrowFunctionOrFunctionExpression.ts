/* Generated file to emulate the ts.refactor.convertArrowFunctionOrFunctionExpression namespace. */

export * from "../refactors/convertArrowFunctionOrFunctionExpression.js";
