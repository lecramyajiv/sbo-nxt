/* Generated file to emulate the ts.BreakpointResolver namespace. */

export * from "../breakpoints.js";
