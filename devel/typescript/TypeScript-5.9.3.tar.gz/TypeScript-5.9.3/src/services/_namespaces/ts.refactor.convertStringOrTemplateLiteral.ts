/* Generated file to emulate the ts.refactor.convertStringOrTemplateLiteral namespace. */

export * from "../refactors/convertStringOrTemplateLiteral.js";
