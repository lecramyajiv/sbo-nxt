/* Generated file to emulate the ts.refactor.convertToOptionalChainExpression namespace. */

export * from "../refactors/convertToOptionalChainExpression.js";
