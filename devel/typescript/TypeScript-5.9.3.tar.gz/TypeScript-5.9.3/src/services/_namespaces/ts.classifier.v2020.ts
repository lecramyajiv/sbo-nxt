/* Generated file to emulate the ts.classifier.v2020 namespace. */

export * from "../classifier2020.js";
