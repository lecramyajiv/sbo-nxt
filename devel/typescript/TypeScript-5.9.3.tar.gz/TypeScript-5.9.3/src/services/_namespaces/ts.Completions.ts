/* Generated file to emulate the ts.Completions namespace. */

export * from "../completions.js";
import * as StringCompletions from "./ts.Completions.StringCompletions.js";
export { StringCompletions };
