/* Generated file to emulate the ts.NavigationBar namespace. */

export * from "../navigationBar.js";
