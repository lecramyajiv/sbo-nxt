/* Generated file to emulate the ts.JsDoc namespace. */

export * from "../jsDoc.js";
