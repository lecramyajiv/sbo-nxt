/* Generated file to emulate the ts.CallHierarchy namespace. */

export * from "../callHierarchy.js";
