/* Generated file to emulate the ts.formatting namespace. */

export * from "../formatting/formattingContext.js";
export * from "../formatting/formattingScanner.js";
export * from "../formatting/rule.js";
export * from "../formatting/rules.js";
export * from "../formatting/rulesMap.js";
export * from "../formatting/formatting.js";
export * from "../formatting/smartIndenter.js";
