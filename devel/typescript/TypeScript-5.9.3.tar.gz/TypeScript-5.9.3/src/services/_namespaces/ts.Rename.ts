/* Generated file to emulate the ts.Rename namespace. */

export * from "../rename.js";
