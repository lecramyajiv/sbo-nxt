/* Generated file to emulate the ts.classifier namespace. */

import * as v2020 from "./ts.classifier.v2020.js";
export { v2020 };
