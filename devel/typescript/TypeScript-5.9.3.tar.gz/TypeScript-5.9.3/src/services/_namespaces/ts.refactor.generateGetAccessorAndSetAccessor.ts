/* Generated file to emulate the ts.refactor.generateGetAccessorAndSetAccessor namespace. */

export * from "../refactors/generateGetAccessorAndSetAccessor.js";
