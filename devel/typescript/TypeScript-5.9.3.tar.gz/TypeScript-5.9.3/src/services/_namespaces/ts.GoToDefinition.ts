/* Generated file to emulate the ts.GoToDefinition namespace. */

export * from "../goToDefinition.js";
