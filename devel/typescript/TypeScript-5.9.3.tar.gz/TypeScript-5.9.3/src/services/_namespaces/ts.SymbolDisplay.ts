/* Generated file to emulate the ts.SymbolDisplay namespace. */

export * from "../symbolDisplay.js";
