/* Generated file to emulate the ts.MapCode namespace. */

export * from "../mapCode.js";
