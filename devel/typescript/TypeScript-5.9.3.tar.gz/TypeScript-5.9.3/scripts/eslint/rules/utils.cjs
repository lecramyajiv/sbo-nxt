const { ESLintUtils } = require("@typescript-eslint/utils");
module.exports.createRule = ESLintUtils.RuleCreator(() => "");
